Your Login OTP Code

Your one-time password (OTP) for login is: {{ $otp }}

This OTP will expire in 15 minutes. Please do not share this code with anyone.

Thanks,
{{ config('app.name') }}