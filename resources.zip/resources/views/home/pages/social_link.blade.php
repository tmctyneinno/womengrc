<ul class="social-link">
    <li>
        <a href="{{ $sociallink->facebook }}" target="_blank"><i class='bx bxl-facebook'></i></a>
    </li> 
    <li>
        <a href="{{ $sociallink->linkedin }}" target="_blank"><i class='bx bxl-linkedin'></i></a>
    </li> 
    <li>
        <a href="{{ $sociallink->instagram }}" target="_blank"><i class='bx bxl-instagram'></i></a>
    </li> 
    {{-- <li>
        <a href="{{ $sociallink->youtube }}" target="_blank"><i class='bx bxl-youtube'></i></a>
    </li>  --}} 
</ul>