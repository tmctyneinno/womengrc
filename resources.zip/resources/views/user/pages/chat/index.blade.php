
@extends('layouts.dashboard') <!-- Or your main layout -->

@section('content')
    @livewire('chat')
@endsection
